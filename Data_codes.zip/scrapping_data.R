library(tidyverse)
library(rvest)
library(RSelenium)
library(readxl)
library(stringr)
library(writexl)

# Funciones

read_review_page_tripadvisor <- function(){
  
  
  #  if (page != ""){  
  
  #    url <- paste0("https://www.tripadvisor.es/Hotel_Review-g187472-d228489-Reviews-or",page,"-Santa_Catalina_a_Royal_Hideaway_Hotel-Las_Palmas_de_Gran_Canaria_Gran_Canaria_Canary_Is.html#REVIEWS") 
  
  #  remDr$navigate(url)
  
  #  Sys.sleep(2)
  #  }
  
  html <- read_html(remDr$getPageSource()[[1]])
  
  
  reviews <- html %>% # Name a variable reviews and take a look at the html
    html_elements(".XllAv") %>% # In particular, look at the class named .cPQsENeY
    html_text()
  
  scores <- html %>%
    html_elements(".emWez") %>%
    html_children() %>% # Look at the child of the named class
    html_attr("class") %>% # Grab the name of the class of the child
    str_remove_all("ui_bubble_rating bubble_") 
  
  dates <- html %>%
    html_elements(".euPKI") %>%
    html_text() %>%
    str_split(":") %>% 
    map_chr(2) %>% 
    str_c("01",.) %>% 
    lubridate::dmy() 
  
  tibble(reviews,scores,dates)
  
}

# rD <- rsDriver(port = 4546L, browser = "firefox")
rD <- rsDriver(browser="firefox", port=45354L, verbose=F)
remDr <- rD$client
# remDr$maxWindowSize()

url.base <- paste0("https://www.tripadvisor.es/Hotel_Review-g187472-d228489-Reviews-Santa_Catalina_a_Royal_Hideaway_Hotel-Las_Palmas_de_Gran_Canaria_Gran_Canaria_Canary_Is.html?filterLang=ALL")

remDr$navigate(url.base)

Sys.sleep(2)

coockie_accept <- remDr$findElement(using = 'id', "onetrust-accept-btn-handler")

coockie_accept$clickElement()

# prueba <- remDr$findElement(using = 'id', "LanguageFilter_0")
# prueba$clickElement()
  
  

# num_reviews <- remDr$findElement(using = "class", "cvxmR")

# num <- num_reviews$getElementText() %>% unlist() %>% str_extract("\\d+")


reviews_all <- read_review_page_tripadvisor()

while (TRUE) {
bnext <- remDr$findElement(using = 'class', "next")
bnext$clickElement()
Sys.sleep(5)

reviews_all <- rbind(reviews_all, read_review_page_tripadvisor())

write_csv(reviews_all,file = "data/tripadvisor_santa_catalina_es.csv")
}
# numpage <- seq(5, num, by = 5) %>% c("",.)



#reviews_all <- map_dfr(numpage[1:3],read_review_page)

remDr$close()
rD$server$stop()


# Booking ####

read_review_page_booking <- function(){
  
 
  
  html <- read_html(remDr$getPageSource()[[1]])
  
  
  reviews <- html %>% # Name a variable reviews and take a look at the html
    html_elements(".review_item_header_content span") %>% # In particular, look at the class named .cPQsENeY
    html_text() %>% 
    str_remove_all("\\n")
  
  scores <- html %>%
    html_elements(".review-score-badge") %>%
    html_text() %>% 
    str_remove_all("\\n") %>% 
    str_replace(",",".") %>% 
    as.numeric() %>% 
    tail(-1)
  
  dates <- html %>%
    html_elements(".review_item_date") %>%
    html_text() %>%
    #str_split(":") %>% 
    lubridate::dmy() 
  
  tibble(reviews,scores,dates)
  
}



rD <- rsDriver(browser="firefox", port=45354L, verbose=F)
remDr <- rD$client

url.base <- paste0("https://www.booking.com/reviews/es/hotel/santa-catalina.es.html?r_lang=all&customer_type=total&order=completed_desc")

remDr$navigate(url.base)

Sys.sleep(2)
 
coockie_accept <- remDr$findElement(using = 'id', "onetrust-accept-btn-handler")

coockie_accept$clickElement()

reviews_all <- read_review_page_booking()

while (TRUE) {
  bnext <- remDr$findElement(using = 'id', "review_next_page_link")
  bnext$clickElement()
  Sys.sleep(10)
  
  reviews_all <- rbind(reviews_all, read_review_page_booking())
  
  write_csv(reviews_all,file = "data/booking_santa_catalina_es.csv")
}
  


# hoteles.com ####

read_review_page_hoteles <- function(){
  
  
  
  html <- read_html(remDr$getPageSource()[[1]])
  
  
  reviews <- html %>% # Name a variable reviews and take a look at the html
    html_elements("h4>span") %>% # In particular, look at the class named .cPQsENeY
    html_text() %>% 
    str_split(" ") %>% 
    map_chr(~.x[-1] %>% 
    str_c(collapse = " "))
  
  scores <- html %>% # Name a variable reviews and take a look at the html
    html_elements("h4>span") %>% # In particular, look at the class named .cPQsENeY
    html_text() %>% 
    str_extract("^[0-9]*") %>% 
    as.numeric()
  
  dates <- html %>%
    html_elements("span[itemprop=datePublished]") %>%
    html_text() %>%
    #str_split(":") %>% 
    lubridate::dmy() 
  
  tibble(reviews,scores,dates)
  

}



rD <- rsDriver(browser="firefox", port=45354L, verbose=F)
remDr <- rD$client

url.base <- paste0("https://es.hoteles.com/ho112322/santa-catalina-a-royal-hideaway-hotel-5-gl-las-palmas-de-gran-canaria-espana")

remDr$navigate(url.base)

Sys.sleep(2)

coockie_accept <- remDr$findElement(using = 'class', "osano-cm-accept-all")

coockie_accept$clickElement()

all_reviews_button <- remDr$findElement(using = 'css selector', ".uitk-spacing-margin-block-three>button")

all_reviews_button$clickElement()

Sys.sleep(5)
reviews_all <- read_review_page_hoteles()

while (TRUE) {
  bnext <- remDr$findElement(using = 'css selector', "div.uitk-spacing.uitk-type-center.uitk-spacing-margin-block-three > button")
  bnext$clickElement()
  Sys.sleep(10)
  
  reviews_all <- rbind(reviews_all, read_review_page_hoteles())
  
  write_csv(reviews_all,file = "data/hoteles_santa_catalina_es.csv")
} 


# fichero unico ####

library(readr)
tripadvisor_santa_catalina_es <- read_csv("data/tripadvisor_santa_catalina_es.csv") 
trpes <- tripadvisor_santa_catalina_es %>% filter(dates > ("2020-12-31") & dates < ("2022-01-01"))
tripadvisor_santa_catalina_en <- read_csv("data/tripadvisor_santa_catalina.csv") 
trpen <- tripadvisor_santa_catalina_en %>% filter(dates > ("2020-12-31") & dates < ("2022-01-01"))
tripadvisor <- rbind(trpes, trpen)  
tabletrip <- tripadvisor %>% 
  group_by(scores) %>% 
  summarise( n = n())

booking <- read_csv("data/booking_santa_catalina_es.csv")
booking <- booking %>% 
  filter(dates > ("2020-12-31") & dates < ("2022-01-01"))
tabletbook <- booking %>% 
  group_by(scores) %>% 
  summarise( n = n())


hoteles <- read_csv("data/hoteles_santa_catalina_es.csv")
hoteles <- hoteles %>% 
  filter(dates > ("2020-12-31") & dates < ("2022-01-01"))
tablethoteles <- hoteles %>% 
  group_by(scores) %>% 
  summarise( n = n())

fichero <- tibble(
  scorestrip = c(tabletrip$scores,rep(NA,11-5)),
  numtrip = c(tabletrip$n,rep(NA,11-5)),
  scoresbooking = tabletbook$scores,
  numbooking = tabletbook$n,
  scoreshoteles  = c(tablethoteles$scores, rep(NA, 11-4)),
  numhoteles = c(tablethoteles$n,rep(NA,11-4))
  
)

write_csv(fichero,"results/scores.csv")


